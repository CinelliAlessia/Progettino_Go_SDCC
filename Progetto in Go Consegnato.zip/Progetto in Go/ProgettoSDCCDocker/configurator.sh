#!/bin/bash

# Leggi il file di configurazione JSON
CONFIG_JSON="./config.json"
ADDRESS_LOAD_BALANCER=$(jq -r .addressLoadBalancer $CONFIG_JSON)
# shellcheck disable=SC2207
ADDRESS_SERVERS=($(jq -r '.addressServers[]' $CONFIG_JSON))
NUMBER_OF_SERVERS=$(jq -r .numberOfServers $CONFIG_JSON)

# Modifica dinamicamente il file docker-docker-compose.yml
sed -i "s/localhost:8080/$ADDRESS_LOAD_BALANCER/" docker-compose.yml

# Modifica le configurazioni dei server in base a quanti sono elencati nel file JSON
# shellcheck disable=SC2004
for ((i=0; i<$NUMBER_OF_SERVERS; i++)); do
  sed -i "s/localhost:808$((i+1))/${ADDRESS_SERVERS[i]}/" docker-compose.yml
done

# Esegui docker-compose up
docker-compose up --build
